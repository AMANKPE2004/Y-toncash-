Pack Yétoncash Mobile-Ready
- Backend Node.js + connecteurs stubs
- Admin UI (React) buildable
- Mobile App Expo
- Config pré-remplie pour commission 5%
- Instructions: Déployer backend sur Render/Railway, build Admin UI sur Netlify/Render, Expo Go pour mobile
- Admin secret: YETON_ADMIN_SECRET_2025